var application = require("application");

application.mainModule = "pages/main-page/main-page";

application.start();
