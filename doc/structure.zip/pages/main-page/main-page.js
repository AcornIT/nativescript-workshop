
var page = null;

exports.onNavigatingTo = function onNavigatingTo(args) {
    page = args.object;
};
